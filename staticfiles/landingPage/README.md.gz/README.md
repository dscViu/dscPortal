# VIU-DSC-App

## install npm

### sudo pacman -S npm

## In project root folder run the following command to install dependencies
### npm install

