import { URISchemeHandler } from "../uri";
declare const handler: URISchemeHandler;
export default handler;
